QUEENSLAND ADVENTURE PLANNER — REMAINING REFINEMENTS

Files
- enhancements.js: complete new refinement script.
- enhancements.css: supporting styles.

Installation
1. Copy enhancements.js and enhancements.css into the root of the GitHub repository, alongside app.js and style.css.
2. In each of these HTML files, add the stylesheet line immediately after the existing refinements.css link:

   <link rel="stylesheet" href="enhancements.css?v=1">

   Files: discover.html, plan-day.html, my-adventures.html, shortlist.html.

3. In each of those same HTML files, add the script line after the existing page-refinements.js script:

   <script src="enhancements.js?v=1" defer></script>

4. Commit the new files and HTML changes, then hard-refresh the site (Ctrl+Shift+R / Cmd+Shift+R).

What this adds
- Equal-height Discover cards with completion buttons aligned at the bottom.
- Removes costs from Discover activity cards and the manual day-planner summary.
- Improves generated itinerary prose using the selected activities' descriptions.
- Changes Add an Adventure to Add an Activity.
- Adds autocomplete suggestions for destinations, regions and categories while retaining free-text entry for new places.
- Hides estimated-cost and cost fields from the Add Activity and personal activity edit forms without deleting existing saved values.
- Renames dog access labels to pet access and updates option wording.
- Makes completed experiences expandable/collapsible on My Adventures.
- Adds an archive/restore workflow for saved itineraries. Archived itineraries remain in localStorage and are not deleted.
- Removes the holiday and duplicate personal-activities groups from the My Adventures dashboard display only; saved holiday data is preserved.
- Improves the Shortlist search placeholder and help text.
- Applies the beige background to the map filters.

Data safety
- The existing adventurePlannerData localStorage key is unchanged.
- Existing activity records, completion history, saved holidays and saved itineraries are retained.
- Archived itinerary IDs are stored in a new archivedItineraries array within the existing data object.
- No distance-filter code is changed.

Important limitation
The activity add/edit forms still retain their existing internal cost fields for backwards compatibility. They are hidden from the interface; old saved cost values are not erased. The autocomplete fields suggest existing destinations, regions and categories but allow new text to be entered.
